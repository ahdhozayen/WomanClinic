/*Dropzone Init*/
$(function(){
	"use strict";
	Dropzone.options.myAwesomeDropzone = {
		addRemoveLinks: true,
		dictResponseError: 'Server not Configured',
		acceptedFiles: ".png,.jpg,.jpeg,.gif,.bmp,.zip",
	};
});

