---
title: "JSZip.version"
layout: default
section: api
---

The version of JSZip as a string.

__Example__

```js
JSZip.version == "3.1.0";
```
